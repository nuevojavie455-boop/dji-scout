package com.dji.scout.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dji.scout.data.DetectionFrame

@Composable
fun StatsBar(
    frame: DetectionFrame?,
    conf: Float,
    onConfChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            if (frame != null) {
                frame.counts.entries.forEach { (cls, cnt) ->
                    StatChip(label = cls, value = cnt.toString(), color = classColor(cls))
                }
                Spacer(modifier = Modifier.weight(1f))
                StatChip(
                    label = "FPS",
                    value = "%.1f".format(frame.fps),
                    color = Color(0xFF4ADE80)
                )
            } else {
                StatChip(label = "person", value = "--", color = Color(0xFF4ADE80))
                StatChip(label = "car", value = "--", color = Color(0xFF60A5FA))
                Spacer(modifier = Modifier.weight(1f))
                StatChip(label = "FPS", value = "--", color = Color(0xFF4ADE80))
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "Confianza:",
                color = Color(0xFF9CA3AF),
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.width(90.dp)
            )
            Slider(
                value = conf,
                onValueChange = onConfChange,
                valueRange = 0.1f..0.95f,
                modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(
                    thumbColor = Color(0xFF4ADE80),
                    activeTrackColor = Color(0xFF4ADE80),
                    inactiveTrackColor = Color(0xFF1E293B)
                )
            )
            Text(
                text = "${(conf * 100).toInt()}%",
                color = Color(0xFF4ADE80),
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.width(38.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.End
            )
        }
    }
}

@Composable
private fun StatChip(label: String, value: String, color: Color) {
    Surface(
        color = color.copy(alpha = 0.12f),
        shape = MaterialTheme.shapes.small
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = label,
                color = color,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = value,
                color = Color.White,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
