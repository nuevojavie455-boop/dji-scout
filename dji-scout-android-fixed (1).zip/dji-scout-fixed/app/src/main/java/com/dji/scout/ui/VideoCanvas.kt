package com.dji.scout.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dji.scout.data.Detection
import com.dji.scout.data.DetectionFrame
import java.text.SimpleDateFormat
import java.util.*

private val colorPerson     = Color(0xFF4ADE80)
private val colorCar        = Color(0xFF60A5FA)
private val colorMotorcycle = Color(0xFFE879F9)
private val colorBus        = Color(0xFFFBBF24)
private val colorTruck      = Color(0xFFF97316)
private val colorDefault    = Color(0xFFFFFFFF)
private val colorHud        = Color(0xFF4ADE80)
private val colorGray       = Color(0xFF9CA3AF)
private val colorBg         = Color(0xFF0A0F1A)

fun classColor(cls: String): Color = when (cls.lowercase()) {
    "person"     -> colorPerson
    "car"        -> colorCar
    "motorcycle" -> colorMotorcycle
    "bus"        -> colorBus
    "truck"      -> colorTruck
    else         -> colorDefault
}

@Composable
fun VideoCanvas(
    bitmap: Bitmap?,
    frame: DetectionFrame?,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .background(colorBg)
    ) {
        if (bitmap != null) {
            drawImage(bitmap.asImageBitmap())
        }

        if (frame != null && bitmap != null) {
            val scaleX = size.width / frame.width.toFloat()
            val scaleY = size.height / frame.height.toFloat()

            frame.dets.forEach { det ->
                drawDetection(det, scaleX, scaleY)
            }

            drawHudOverlay(frame)
        } else {
            drawNoSignal()
        }
    }
}

private fun DrawScope.drawDetection(det: Detection, scaleX: Float, scaleY: Float) {
    val color = classColor(det.cls)
    val x1 = det.x1 * scaleX
    val y1 = det.y1 * scaleY
    val x2 = det.x2 * scaleX
    val y2 = det.y2 * scaleY
    val cornerSize = 12.dp.toPx()
    val strokeWidth = 2.dp.toPx()

    // Top-left corner
    drawLine(color, Offset(x1, y1), Offset(x1 + cornerSize, y1), strokeWidth)
    drawLine(color, Offset(x1, y1), Offset(x1, y1 + cornerSize), strokeWidth)
    // Top-right corner
    drawLine(color, Offset(x2, y1), Offset(x2 - cornerSize, y1), strokeWidth)
    drawLine(color, Offset(x2, y1), Offset(x2, y1 + cornerSize), strokeWidth)
    // Bottom-left corner
    drawLine(color, Offset(x1, y2), Offset(x1 + cornerSize, y2), strokeWidth)
    drawLine(color, Offset(x1, y2), Offset(x1, y2 - cornerSize), strokeWidth)
    // Bottom-right corner
    drawLine(color, Offset(x2, y2), Offset(x2 - cornerSize, y2), strokeWidth)
    drawLine(color, Offset(x2, y2), Offset(x2, y2 - cornerSize), strokeWidth)

    // Label
    val idStr = if (det.id != null) " #${det.id}" else ""
    val label = "${det.cls}$idStr  ${(det.conf * 100).toInt()}%"
    val textSize = 10.sp.toPx()
    val textPaint = android.graphics.Paint().apply {
        this.textSize = textSize
        this.color = android.graphics.Color.BLACK
        this.isAntiAlias = true
    }
    val textWidth = textPaint.measureText(label)
    val textHeight = textPaint.descent() - textPaint.ascent()
    val padH = 4.dp.toPx()
    val padV = 2.dp.toPx()
    val bgLeft = x1
    val bgTop = (y1 - textHeight - padV * 2).coerceAtLeast(0f)
    val bgRight = x1 + textWidth + padH * 2
    val bgBottom = bgTop + textHeight + padV * 2

    drawIntoCanvas { canvas ->
        val bgPaint = Paint().apply { this.color = color }
        canvas.drawRect(
            left = bgLeft,
            top = bgTop,
            right = bgRight,
            bottom = bgBottom,
            paint = bgPaint
        )
        canvas.nativeCanvas.drawText(
            label,
            bgLeft + padH,
            bgBottom - padV - textPaint.descent(),
            textPaint
        )
    }
}

private fun DrawScope.drawHudOverlay(frame: DetectionFrame) {
    val margin = 10.dp.toPx()
    val textSize = 11.sp.toPx()

    val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(frame.ts.takeIf { it > 0 } ?: System.currentTimeMillis()))

    drawIntoCanvas { canvas ->
        val greenPaint = android.graphics.Paint().apply {
            color = colorHud.toArgb()
            this.textSize = textSize
            isAntiAlias = true
            typeface = android.graphics.Typeface.MONOSPACE
        }
        val grayPaint = android.graphics.Paint().apply {
            color = colorGray.toArgb()
            this.textSize = (9.sp).toPx()
            isAntiAlias = true
            typeface = android.graphics.Typeface.MONOSPACE
        }

        // Top-left: LIVE + time
        canvas.nativeCanvas.drawText("● LIVE  $timeStr", margin, margin + textSize, greenPaint)

        // Top-right: FPS
        val fpsStr = "${"%.1f".format(frame.fps)} FPS"
        val fpsWidth = greenPaint.measureText(fpsStr)
        canvas.nativeCanvas.drawText(fpsStr, size.width - fpsWidth - margin, margin + textSize, greenPaint)

        // Bottom-left: counts
        var xOffset = margin
        val countY = size.height - margin - 4.dp.toPx()
        frame.counts.entries.forEach { (cls, cnt) ->
            val txt = "$cls: $cnt  "
            val paint = android.graphics.Paint().apply {
                color = classColor(cls).toArgb()
                this.textSize = textSize
                isAntiAlias = true
                typeface = android.graphics.Typeface.MONOSPACE
            }
            canvas.nativeCanvas.drawText(txt, xOffset, countY, paint)
            xOffset += paint.measureText(txt)
        }

        // Bottom-center: watermark
        val watermark = "DJI Mini 4K  |  YOLO11s  |  ByteTrack"
        val wmWidth = grayPaint.measureText(watermark)
        canvas.nativeCanvas.drawText(
            watermark,
            (size.width - wmWidth) / 2f,
            size.height - margin,
            grayPaint
        )
    }
}

private fun DrawScope.drawNoSignal() {
    drawIntoCanvas { canvas ->
        val paint = android.graphics.Paint().apply {
            color = colorHud.toArgb()
            textSize = 14.sp.toPx()
            isAntiAlias = true
            typeface = android.graphics.Typeface.MONOSPACE
            textAlign = android.graphics.Paint.Align.CENTER
        }
        canvas.nativeCanvas.drawText(
            "NO SIGNAL — WAITING FOR CONNECTION",
            size.width / 2f,
            size.height / 2f,
            paint
        )
    }
}
