package com.dji.scout.data

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.json.Json
import okhttp3.*
import java.util.concurrent.TimeUnit

class WebSocketManager(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("dji_scout_prefs", Context.MODE_PRIVATE)

    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private val json = Json { ignoreUnknownKeys = true }

    private val _frame = MutableStateFlow<DetectionFrame?>(null)
    val frame: StateFlow<DetectionFrame?> = _frame

    private val _bitmap = MutableStateFlow<Bitmap?>(null)
    val bitmap: StateFlow<Bitmap?> = _bitmap

    private val _connected = MutableStateFlow(false)
    val connected: StateFlow<Boolean> = _connected

    private var webSocket: WebSocket? = null
    private var reconnectJob: Job? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private var currentIp: String = prefs.getString("server_ip", "192.168.1.100") ?: "192.168.1.100"
    private var currentPort: Int = prefs.getInt("server_port", 8000)

    fun getSavedIp(): String = currentIp
    fun getSavedPort(): Int = currentPort

    fun connect(ip: String, port: Int = 8000) {
        currentIp = ip
        currentPort = port
        prefs.edit().putString("server_ip", ip).putInt("server_port", port).apply()
        reconnectJob?.cancel()
        doConnect(ip, port)
    }

    private fun doConnect(ip: String, port: Int) {
        webSocket?.cancel()
        val request = Request.Builder()
            .url("ws://$ip:$port/ws")
            .build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                _connected.value = true
                reconnectJob?.cancel()
            }

            override fun onMessage(ws: WebSocket, text: String) {
                scope.launch {
                    try {
                        val detectionFrame = json.decodeFromString<DetectionFrame>(text)
                        _frame.value = detectionFrame
                        val bytes = Base64.decode(detectionFrame.frame, Base64.DEFAULT)
                        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        if (bmp != null) {
                            _bitmap.value = bmp
                        }
                    } catch (_: Exception) {
                    }
                }
            }

            override fun onClosing(ws: WebSocket, code: Int, reason: String) {
                _connected.value = false
                ws.close(1000, null)
                scheduleReconnect()
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                _connected.value = false
                scheduleReconnect()
            }
        })
    }

    private fun scheduleReconnect() {
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            delay(3000)
            if (!_connected.value) {
                doConnect(currentIp, currentPort)
            }
        }
    }

    fun disconnect() {
        reconnectJob?.cancel()
        webSocket?.close(1000, "User disconnected")
        webSocket = null
        _connected.value = false
    }

    fun sendConf(conf: Float) {
        val payload = """{"conf": ${"%.2f".format(conf)}}"""
        webSocket?.send(payload)
    }

    fun close() {
        disconnect()
        scope.cancel()
    }
}
