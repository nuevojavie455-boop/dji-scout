package com.dji.scout.viewmodel

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dji.scout.data.DetectionFrame
import com.dji.scout.data.WebSocketManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn

class ScoutViewModel(application: Application) : AndroidViewModel(application) {

    val wsManager = WebSocketManager(application)

    val frame: StateFlow<DetectionFrame?> = wsManager.frame
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val bitmap: StateFlow<Bitmap?> = wsManager.bitmap
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val connected: StateFlow<Boolean> = wsManager.connected
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    private val _conf = MutableStateFlow(0.35f)
    val conf: StateFlow<Float> = _conf

    fun setConf(value: Float) {
        _conf.value = value
        wsManager.sendConf(value)
    }

    fun connect(ip: String, port: Int = 8000) = wsManager.connect(ip, port)
    fun disconnect() = wsManager.disconnect()

    fun getSavedIp(): String = wsManager.getSavedIp()
    fun getSavedPort(): Int = wsManager.getSavedPort()

    override fun onCleared() {
        super.onCleared()
        wsManager.close()
    }
}
