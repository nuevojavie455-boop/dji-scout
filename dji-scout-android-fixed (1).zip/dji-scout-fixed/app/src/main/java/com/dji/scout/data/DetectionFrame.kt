package com.dji.scout.data

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Detection(
    val id: Int? = null,
    val cls: String,
    val conf: Float,
    val x1: Int,
    val y1: Int,
    val x2: Int,
    val y2: Int
)

@Serializable
data class DetectionFrame(
    val frame: String,
    val dets: List<Detection> = emptyList(),
    val width: Int,
    val height: Int,
    val fps: Float = 0f,
    val counts: Map<String, Int> = emptyMap(),
    val ts: Long = 0L
)
